package com.example.alarmy

data class AlarmItem(
    val time: String,
    val isEnabled: Boolean
)
