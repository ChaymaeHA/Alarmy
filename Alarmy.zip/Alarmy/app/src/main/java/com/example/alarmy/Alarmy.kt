package com.example.alarmy

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Switch
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class AlarmAdapter(
    private val alarms: List<AlarmItem>,
    private val onSwitchToggled: (Int, Boolean) -> Unit
) : RecyclerView.Adapter<AlarmAdapter.AlarmViewHolder>() {

    class AlarmViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val timeText: TextView = view.findViewById(R.id.text_time)
        val alarmSwitch: Switch = view.findViewById(R.id.switch_alarm)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlarmViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_alarm, parent, false)
        return AlarmViewHolder(view)
    }

    override fun onBindViewHolder(holder: AlarmViewHolder, position: Int) {
        val alarm = alarms[position]
        holder.timeText.text = alarm.time
        holder.alarmSwitch.isChecked = alarm.isEnabled

        holder.alarmSwitch.setOnCheckedChangeListener { _, isChecked ->
            onSwitchToggled(position, isChecked)
        }
    }

    override fun getItemCount(): Int = alarms.size
}

