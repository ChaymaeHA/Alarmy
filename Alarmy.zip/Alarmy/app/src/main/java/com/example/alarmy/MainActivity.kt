package com.example.alarmy

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private val alarmList = mutableListOf<AlarmItem>()
    private lateinit var alarmAdapter: AlarmAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.recycler_view)
        val addButton: Button = findViewById(R.id.button_add_alarm)

        alarmAdapter = AlarmAdapter(alarmList) { position, isEnabled ->
            // Handle toggle logic here
            alarmList[position] = alarmList[position].copy(isEnabled = isEnabled)
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = alarmAdapter

        addButton.setOnClickListener {
            showAddAlarmDialog()
        }
    }

    private fun showAddAlarmDialog() {
        val dialogBuilder = AlertDialog.Builder(this)
        val timePicker = TimePicker(this)
        timePicker.setIs24HourView(true)

        dialogBuilder.setView(timePicker)
        dialogBuilder.setTitle("Set Alarm")
        dialogBuilder.setPositiveButton("Add") { _, _ ->
            val hour = timePicker.hour
            val minute = timePicker.minute
            val time = String.format("%02d:%02d", hour, minute)
            alarmList.add(AlarmItem(time, false))
            alarmAdapter.notifyItemInserted(alarmList.size - 1)
        }
        dialogBuilder.setNegativeButton("Cancel", null)
        dialogBuilder.show()
    }
}
